---
name: plc-scl-gen-04
description: "SCL控制程序生成与编译闭环：基于阶段3 io_address.xlsx、DB定义、FB/FC接口契约和已确认需求，按西门子S7-1200/TIA Portal V21规范生成OB/FB/FC独立.scl源文件，执行静态预检、编译、错误定位与最多3轮修复，输出compilation_fix_shturl；严格执行定时器/计数器静态化、FC输出全分支赋值、DO单一写入者、契约内符号约束。"
whenToUse: "当IO地址、DB、FB/FC接口和需求已确认，需要生成S7-1200 SCL程序、做TIA导入前静态检查、进入编译反馈修复闭环时使用。"
---

> **【2026-11-16 强制增补】** 本技能新增《附录 Z：实机回归失败模式与强制检查》，由一次真实项目的实机回归反推而成（81 条用例在 PLCSIM 上真实执行，56 通过 / 25 不符；项目与设备信息已脱敏）。**开工前必读**；附录中带编号的条目（R-/B-/S-/T-/E-/G-）为硬性要求，交付前逐条自检。

# SCL控制程序生成与编译闭环（plc-scl-gen-04）

## 0. 角色、目标与红线

角色：西门子 S7-1200/S7-1500 PLC 程序开发工程师，专注 SCL；目标平台 **TIA Portal V21**，CPU 型号**由项目实际硬件决定**——阶段4开始时用 `GetProjectTree` / `GetDevices` 读取，禁止写死 1214C，禁止猜测。

目标：

1. 在 `./output/04-scl/src/` 下按 OB/FB/FC 分文件输出 `.scl` 源程序；
2. 执行静态预检、TIA 导入/编译、错误定位与最多3轮自动修复；
3. 输出 `./output/04-scl/compilation_fix_shturl` 编译报错与修复日志；
4. 3轮仍不通过时转人工接管，不伪造编译通过。

红线：

1. **IEC定时器/CTU计数器必须在静态区**：FB 的静态区在 TIA SCL 源中写作 `VAR ... END_VAR`，**不是** `VAR_STATIC`；禁止放在 `VAR_TEMP`。FC 无静态区，定时器/计数器必须通过契约中的 InOut/背景DB传入，或改由FB持有。
2. **FC所有输出全分支赋值**：每条路径都要给所有输出赋值；推荐“临时变量先赋默认值→分支计算→末尾一次性赋输出”。禁止脏输出。
3. **DO单一写入者**：同一DO在整个项目中只能有一个拥有块负责写入；其他块只能读或通过参数传递；禁止在多处重复赋值。
4. **只用契约内符号**：IO符号、DB成员、FB/FC/OB接口、静态/临时变量都必须来自输入契约；不得私自新增变量、DB、接口、块。
5. **TIA V21导入合规**：块声明/结束关键字、变量段顺序、编码、注释、时间字面量符合TIA SCL外部源格式。
6. **不伪造编译**：没有TIA Openness/MCP编译通道或真实编译日志时，只能做静态预检并标“编译未执行”；不得编造错误码/编译结果。
7. **不做逻辑验证**：编译通过只代表语法/接口通过，不代表逻辑正确；不仿真、不调试、不生成HMI/图纸。

**快速导航**：1 输入输出｜2 代码契约｜3 SCL格式与模板｜4 生成流程｜5 静态预检｜6 编译修复闭环｜7 日志｜8 交付自检｜9 对话契约｜附录

---

## 1. 输入、输出与前置检查

### 1.1 输入

| 输入 | 默认路径 | 用途 | 必需 |
|---|---|---|---|
| PLC 变量表映射 | `./output/03-electrical/plc_tag_map.csv` | 符号名、地址、数据类型、方向、NC语义（阶段3 导出，**符号唯一来源**） | 是 |
| PLC 变量表 XML | `./output/03-electrical/plc_tag_table.xml` | 供 `ImportPlcTagTable` 导入；仅 PLC 变量，排除 HMI（阶段3 导出） | 是（TIA 导入必需） |
| 结构化IO地址表 | `./output/03-electrical/io_address.xlsx` | IO符号、地址、类型、方向、NC语义、REQ（与上一行交叉核对） | 是 |
| DB数据块定义 | `./output/04-scl/db_definitions.xlsx` 或用户指定 | DB名/成员/类型/默认值 | 是（`auto_simulate_customer=true` 时可生成草案） |
| FB/FC接口契约 | `./output/04-scl/interface_contract.md`/`.xlsx`/`.json` 或用户指定 | 块名、接口、静态/临时变量、实例DB、调用关系 | 是（`auto_simulate_customer=true` 时可生成草案） |
| 已确认需求规格 | `./output/01-requirements/requirements_spec.xlsx` | 功能/边界/验收追溯 | 是 |
| 编译通道/日志 | TIA Openness/MCP 或 `compile_log.txt` | 真实编译反馈 | 编译必需 |
| 用户补充 | 对话/参数 | 块清单、调用关系、工程前置说明 | 否 |

路径规则：

- 用户明确路径优先；否则按上表默认，找不到可在 `./input/` 回退，但必须在日志记录实际路径。
- 输入缺失/表头不符/文件是CSV改名：停止并返回：

```text
【缺少输入：io_address.xlsx / plc_tag_table.xml / DB定义 / 接口契约 / requirements_spec.xlsx】
```

- 若接口契约已经包含IO/DB切片，仍要与 `io_address.xlsx` 和DB定义交叉核对；冲突时停止，不猜。

### 1.2 输出

| 输出 | 固定路径 | 说明 |
|---|---|---|
| SCL源文件 | `./output/04-scl/src/` | 每块一个 `.scl`；只放OB/FB/FC；不放DB/HMI/图纸。唯一允许的例外：`./output/04-scl/src/使用说明/` 子目录，仅放使用说明 `.md`（不得与 `.scl` 同级混放其他文件） |
| 源码使用说明 | `./output/04-scl/src/使用说明/使用说明.md` | **推荐交付物（不阻断）**：给工程师的导入/编译/下载/调试步骤、前置工程对象清单、编码与乱码处理、常见故障排查、已知限制与免责；不得包含“已验证/可现场运行”等结论 |
| 编译修复日志 | `./output/04-scl/compilation_fix_shturl` | 文件名无扩展名；Markdown式文本 |

生成前创建 `./output/04-scl/src/`；如生成使用说明，再创建 `./output/04-scl/src/使用说明/`。

源文件命名默认：

```text
OB_<BlockName>.scl
FB_<BlockName>.scl
FC_<BlockName>.scl
```

- 文件名用ASCII；块名以契约/块头为准；文件名中的空格替换为`_`，块头不改名。
- 一块一文件；不要把多个块塞进一个 `.scl`。
- 使用说明固定写入 `./output/04-scl/src/使用说明/使用说明.md`（目录不存在则创建）；文件名不得改成 `README.txt` 等，也不得放在 `./output/` 根目录下。
- 不输出 `DATA_BLOCK` 源文件、HMI文件、电气图纸、仿真文件。

### 1.3 阻塞/部分输出

| 情况 | 处理 |
|---|---|
| 缺IO符号/DB成员/接口/静态实例 | 停止该块，标 `【契约缺口：...】`；不新增。**模拟模式例外：按下表生成契约草案** |
| 缺 `plc_tag_table.xml` | 停止，回到阶段3 导出；不得从 CSV 直接导入 |
| 定时器/计数器只能放TEMP | 停止，要求契约补静态实例；不得用TEMP（模拟模式：草案中补静态实例，标 `【模拟契约】`） |
| FC需要背景实例但契约无InOut/DB | 停止，要求契约补；不得自建实例（模拟模式：草案中用 `VAR_IN_OUT` 传入背景 DB，标 `【模拟契约】`） |
| DO存在多个拥有块 | 停止，要求契约明确唯一拥有者；不得重复写（模拟模式：草案中指定唯一拥有块，标 `【模拟契约】`） |
| 全局 DB/OB1/tag 表缺失（编译时） | 停止并标 `【工程前置缺口：...】`；仅源码模式记录 `编译未执行：工程对象缺失`，不创建全局 DB/tag 表 |
| 无TIA编译通道 | 只做静态预检，日志标`编译未执行`；不编造 |
| 3轮修复仍失败 | 停止，转人工；保留残余错误 |
| 输入契约冲突 | 停止；修改输入不是本技能职责（模拟模式：草案中按保守方案定夺，标 `【模拟契约】`） |

“部分生成”必须在日志/回复中列明哪些块未生成、为什么。

#### 1.3.1 契约草案（仅 `auto_simulate_customer=true`）

当 DB 定义或接口契约缺失（或调用上下文传 `AUTO_DRAFT`）时，不阻塞，按下列顺序生成草案并落盘：

1. 从 `./output/03-electrical/io_address.xlsx` 取 IO 符号/类型/物理地址/REQ；
2. 从 `./output/01-requirements/requirements_spec.xlsx` 取已确认与 `【模拟回答】` 的 REQ，按工艺段归纳块清单；
3. 生成 `./output/04-scl/db_definitions.xlsx`（DB名/成员/类型/数组/默认值/保持性）与 `./output/04-scl/interface_contract.md`（块清单/接口/静态区/实例DB/调用图/边界条件/DO所有权/IO语义）；
4. 在 `00-说明` 或文档头逐条标 `【模拟契约】`，并写明“草案未在 TIA 项目中存在，导入前须人工核对”；
5. 若后续用户提供了真实契约，以真实契约为准，草案作废并升版本号。

### 1.4 工具与平台

- 文件读写/shell：`read_file`/`write_file`/`bash`（本环境`read`/`write`/`pwsh`）。
- 读取xlsx用`openpyxl`；生成 `.scl` 用文本写入，不经过xlsx。
- 编译通道：TIA Portal Openness、TIA MCP 或项目提供的编译工具；没有就如实标记。
- 禁止用PLCSIM/仿真替代编译；禁止用LLM猜测编译消息。

---

## 2. 代码契约（生成前必须完成）

### 2.1 契约对象

构建 `code_contract`，至少包含：

```text
project / cpu / tia_version
blocks[]        块类型/块名/接口/静态/临时/实例DB/调用者
io_symbols[]    IO符号/地址/类型/方向/NC语义/安全状态/拥有块/REQ
db_defs[]       DB名/成员/类型/数组/默认值/保持性
boundaries[]    急停/复位/掉电/异常/安全状态/REQ
do_owners[]     每个DO的唯一拥有块/写入方式
call_graph[]    调用者/被调用者/实例DB/顺序
compile_adapter 工具/日志/版本
```

契约只汇总输入，不创造新符号。需要新增内部变量/静态实例时，只能列为“契约变更请求”，不直接写进代码。

### 2.2 IO符号

**符号唯一来源：阶段3 的 `./output/03-electrical/plc_tag_map.csv`**（列：`IO-ID,Symbol,Address,DataType,Direction,NcSemantic,REQ-ID`）；TIA 导入文件为同目录的 `./output/03-electrical/plc_tag_table.xml`。两者均由阶段3 导出，本阶段**只读、直接引用，不改名、不新建符号**。

- 符号优先级：`plc_tag_map.csv` 的 `Symbol` > `io_address.xlsx` 的 `PLC符号` > `设备标签`；三者不一致时以 `plc_tag_map.csv` 为准并报不一致（不得自己挑一个用）。
- 类型：DI/DO、内部 M 位为`Bool`；AI/AO、内部 MW 字为`Int`/`Real`/`Word`，取 `plc_tag_map.csv` 的 `DataType`，其来源必须是接口契约/DB定义/模块通道类型，不能根据“模拟量”三个字猜；HMI 不进入 PLC 变量表。
- 物理地址、IO-ID、REQ、设备标签、备用标志、回路号保留用于追溯。
- `备用` 行不生成代码；`内部`/`HMI` 仅在契约引用时使用；HMI标签不由PLC程序直接写，除非契约明确。
- NC/安全语义取 `plc_tag_map.csv` 的 `NcSemantic`（`NO`=TRUE为动作 / `NC`=FALSE为正常）：`TRUE=安全`或`FALSE=安全`不得猜；缺失→契约缺口，停止。
- 不得用 `IO-001` 这类带连字符的ID当SCL标识符。
- 变量表由阶段3 的 `plc_tag_table.xml` 导入（`ImportPlcTagTable(softwarePath, folderPath, importPath)`）；CSV 仅作人类可读源，不直接导入。本阶段**不得自建或手改 PLC tag 表**；发现缺失/冲突只报缺口，回到阶段3。
- 若 `plc_tag_map.csv`/`plc_tag_table.xml` 不存在或与 `io_address.xlsx` 不一致：
  - `auto_simulate_customer=false`：停止（`E07_IO_ADDRESS_MISSING` 或契约缺口），不得在代码里散落绝对地址；
  - `auto_simulate_customer=true`：允许按 `SIG_` 规则**临时**生成符号并落盘到 `./output/04-scl/_work/plc_tag_map.fallback.csv`，同时按同一映射生成 fallback XML（不得覆盖阶段3 的原文件），代码中只允许使用该集合内的符号，每处与报告都标 `【模拟契约】符号为自动生成，需在 TIA 侧按项目命名规范改名`；绝对地址只允许出现在注释与该 CSV/XML，不得出现在逻辑语句里。

### 2.3 DB定义

- DB名、成员名、类型、数组、默认值、保持性必须逐字使用。
- DB定义只读；不得修改全局 DB、不得新增 DB 成员、不得生成 DB 源文件。
- 代码访问格式：`"DB_Name".Member`；数组/结构按契约。
- 全局 DB 不存在/成员不存在：编译会报错；本技能不改全局 DB，只报契约/工程前置缺口。
- 全局 DB 必须已存在于 TIA 项目；本技能不创建全局 DB。
- 实例 DB：必须在契约中明确名称/编号；FB 生成后可按契约用 `CreateInstanceDB` 创建，已存在则复用并校验接口，不重复创建；不得自定名称或新建契约外实例。

### 2.4 FB/FC/OB接口

- 块类型、块名、变量段、变量名、类型、默认值、注释逐字使用。
- **FB静态区在SCL源中是 `VAR ... END_VAR`**，不是 `VAR_STATIC`；静态变量包括定时器/计数器/边沿实例/状态。
- **FC没有静态区**；不能声明 `VAR` 静态段；需要保持的数据/实例通过 `VAR_IN_OUT` 或背景DB传入。
- 变量段顺序按TIA接口：`VAR_INPUT` → `VAR_OUTPUT` → `VAR_IN_OUT` → `VAR`（静态）→ `VAR_TEMP`。
- 实例DB/多重实例路径必须在契约中明确；可按契约名称/编号创建，不得自定或改名。
- 不得新增/删除/改名接口参数；不得改变类型/默认值。

### 2.5 边界条件

必须从需求/契约整理：

- 急停：安全状态、输出复位、复位方式、是否保持；
- 正常停止/复位：停止类别、复位条件；
- 掉电/上电：保持/非保持、禁止自动重启；
- 异常：传感器故障、超时、通讯丢失、非法步号；
- 每个边界的REQ来源、优先级、期望输出。

边界条件缺失：不得自己补一套安全逻辑；列为契约缺口，停止相关块或整项目。

**模拟模式（仅 `auto_simulate_customer=true`）**：边界条件由 §1.3.1 契约草案补齐（急停/掉电/复位/超时/传感器故障），逐条标 `【模拟契约】`；补齐后仍无法确定的边界，该块不生成，按“部分生成”报告，不得把边界写成已确认。

### 2.6 DO单一写入者

- 为每个DO建立 `do_owners`：`DO符号 → 唯一拥有块 → 写入方式`。
- 同一DO不得在OB/FB/FC多处赋值；其他块只能读或用输出参数传递。
- OB1原则上只做块调用/接线，不直接写DO；DO写入放在拥有FB/FC。
- 若需求导致多个块都要控制同一DO：合并到拥有块，或由拥有块接收其他块命令；不得双重赋值。
- 若契约无法确定唯一拥有者：停止该DO，要求契约裁决。

**模拟模式（仅 `auto_simulate_customer=true`）**：由 §1.3.1 草案按信号语义指定唯一拥有块（执行机构/安全/诊断等各自归块），标 `【模拟契约】`；确实无法归块的 DO 不生成任何写入语句，并列入“部分生成”说明。

### 2.7 调用关系

- 建 `call_graph`：OB→FB/FC；FB→FB/FC；实例DB/多重实例。
- 生成顺序：叶子块→父块→OB；禁止循环调用；禁止调用未定义块。
- 每个调用参数必须与接口契约名称/类型/方向一致；输出用 `=>`，输入用 `:=`。
- 不得自定/改名实例DB；可按契约名称/编号创建；不得调用契约外块。

### 2.8 契约校验

生成代码前必须通过：

- 每个块有类型/名称/完整接口/调用者；
- 每个IO符号在PLC tag表/契约内；每个DB成员在DB定义内；
- 定时器/计数器/边沿实例都在FB静态区；FC没有静态实例；
- 每个FC输出有全分支赋值策略；每个DO有唯一拥有者；
- 每个边界有REQ；每个需求有块落点；
- 无循环调用；无未定义块/实例DB；
- 契约冲突/缺失→停止，不进入代码生成。

**模拟模式（仅 `auto_simulate_customer=true`）**：上面任何一项因契约缺失而不满足时，按 §1.3.1 生成草案补齐该项（标 `【模拟契约】`）后重新校验，仍通过则可继续生成；补齐后依然不满足的项（如无法确定唯一 DO 拥有者、FC 强制需要静态实例）不进入代码生成，按“部分生成”报告，不得硬写。

---

## 3. SCL格式与模板（TIA Portal V21 / S7-1200）

### 3.1 文件格式

- 每个 `.scl` 文件只放一个块：OB/FB/FC。
- 文件头注释包含：块名/类型、CPU/TIA版本、用途、REQ、接口摘要、边界、生成日期、“逻辑未验证”。
- 编码：**UTF-8 with BOM（首 3 字节 `EF BB BF`）+ CRLF**。中文注释必须带 BOM。
  - 原因：无 BOM 的 UTF-8 会被中文 Windows 的记事本／部分编辑器／部分 SCL 导入器按 ANSI(GBK) 解析，中文注释显示为 `瀹夊叏鐩戞帶` 类乱码，被误判为“注释不是中文”。同一段字节按 GBK 解码即可复现该现象。
  - 生成：Python 用 `open(p, "w", encoding="utf-8-sig", newline="")` 一次写完；完成后必须回读字节，校验前 3 字节为 `EF BB BF`，并确认 CRLF 存在。
  - 唯一例外：项目已明确要求“无 BOM”（TIA 侧已验证或版本库禁止 BOM）时，必须二选一并写入日志：① 中文注释转 GBK 编码；② 注释改英文/拼音。**禁止**把“UTF-8 无 BOM + 中文注释”直接交付。
- **块标题/网络标题禁止中文（2026-11-15 实测）**：`.s7dcl` 的 `S7_BlockTitle` / `S7_NetworkTitle` 写中文会导致导入失败或 0 块；标题一律 ASCII。
- **中文放三层，别混为一谈**：① `S7_BlockTitle`/`S7_NetworkTitle`（导入元数据）= **必须 ASCII**；② 变量声明同一行 `// 中文` 与 `BEGIN`/`NETWORK` 内注释 = **中文，且必须有**；③ `.scl` 文件头注释块（块名/用途/REQ/契约）= **中文**。静态预检只检第 ②③ 层，不因第 ① 层是 ASCII 就判"注释非中文"。
- **中文注释的正确位置（实测保留）**：① 变量声明同一行 `// 中文` → 进 `.s7res` 的 `zh-CN` MLC，不是丢注释；② `BEGIN` / `NETWORK` 内的 `// 中文` → 保留在块体。
- **导入后必须回读校验（硬门禁）**：`ExportAsDocuments` 导出该块，逐字比对中文；出现 `涓`、`锛`、`鍙`、`鏂`、`鐨` 等 GBK 误解码特征，或与源文不一致 → 判 `E08_ENCODING_MOJIBAKE`，禁止交付或声称编译通过。
- `.s7res` 仅有 `zh-CN` 时导入会报 `missingEnUsIds` 警告：**这是提示不是错误**，只要 `zh-CN` 文本与源文一致即通过。
- 标识符用ASCII；中文只放注释，不放变量/块名（除非契约已用且TIA项目验证）。
- 缩进一致（建议3/4空格）；语句分号；块结束关键字后不加分号。

### 3.2 OB模板

```scl
ORGANIZATION_BLOCK "OB_Main"
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
   VAR_TEMP
      // 仅契约允许的临时变量；没有则删除本段
      tmp : Bool;
   END_VAR
BEGIN
	// OB只做调用/接线；不在OB重复写DO
	"FB_Conveyor_DB"(
	    Start := "DI_Start",
	    Running => "DO_Run");
END_ORGANIZATION_BLOCK
```

- OB名/文件按契约；`END_ORGANIZATION_BLOCK` 后无分号。
- 无接口参数时不要写 `VAR_INPUT`/`VAR_OUTPUT`。
- 不写 `PROGRAM`/`END_PROGRAM`。

### 3.3 FB模板

```scl
FUNCTION_BLOCK "FB_Conveyor"
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
   VAR_INPUT
      Start : Bool;                 // 启动命令
      Stop : Bool;                  // 停止命令
   END_VAR
   VAR_OUTPUT
      Run : Bool;                   // 运行输出（本块唯一写入者）
   END_VAR
   VAR_IN_OUT
      // 契约定义的InOut；没有则删除
   END_VAR
   VAR
      // 静态区：TIA SCL源写VAR，不写VAR_STATIC
      TonRun : TON_TIME;            // 运行延时
      CtuPart : CTU_INT;            // 计数
      EdgeStart : R_TRIG;           // 上升沿
      State : Int;                  // 状态
   END_VAR
   VAR_TEMP
      tmpRun : Bool;                // 契约允许的临时变量
   END_VAR
BEGIN
	// 逻辑；定时器/计数器/边沿只用静态实例
	#EdgeStart(CLK := #Start);
	#TonRun(IN := #Start AND NOT #Stop, PT := T#2S);
	#tmpRun := #TonRun.Q;
	#Run := #tmpRun;
END_FUNCTION_BLOCK
```

- `VAR` 是静态区；`VAR_STATIC` 在TIA SCL外部源中不是合法关键字。
- 定时器类型：`TON_TIME`/`TOF_TIME`/`TP_TIME` 等；计数器：`CTU_INT`/`CTU_DINT` 等，按契约。
- 边沿`R_TRIG`/`F_TRIG`也放静态区；不要放`VAR_TEMP`。
- `END_FUNCTION_BLOCK` 后无分号。

### 3.4 FC模板

```scl
FUNCTION "FC_Alarm" : Void
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
   VAR_INPUT
      Fault : Bool;
   END_VAR
   VAR_OUTPUT
      Lamp : Bool;
      Buzzer : Bool;
   END_VAR
   VAR_IN_OUT
      // 契约定义
   END_VAR
   VAR_TEMP
      tmpLamp : Bool;               // 契约允许的临时变量
      tmpBuzzer : Bool;
   END_VAR
BEGIN
	// FC无静态区；定时器/计数器不得放TEMP
	#tmpLamp := FALSE;
	#tmpBuzzer := FALSE;

	IF #Fault THEN
	    #tmpLamp := TRUE;
	    #tmpBuzzer := TRUE;
	ELSE
	    #tmpLamp := FALSE;
	    #tmpBuzzer := FALSE;
	END_IF;

	// 输出末尾一次性赋值，避免脏输出
	#Lamp := #tmpLamp;
	#Buzzer := #tmpBuzzer;
END_FUNCTION
```

- FC不能写 `VAR` 静态段；`VAR_STATIC` 更不允许。
- 输出可以用临时变量末尾赋值；如果契约没有临时变量，用互斥 `IF/ELSE`/`CASE` 在每个分支给所有输出赋值，不要新增临时变量。
- 不得在输出赋值前 `RETURN`。

### 3.5 DB访问与调用

```scl
"DB_Vision".Trigger := TRUE;
#Local := "DB_Vision".Valid;
"FB_Conveyor_DB"(Start := "DI_Start", Run => "DO_Run");
```

- 全局：`"BlockOrDB".Member`；本地：`#Var`。
- 调用输入 `:=`，输出 `=>`。
- 实例DB/多重实例路径必须来自契约；可按契约名称/编号创建，不得自定。
- 不允许把IO绝对地址散落在代码里，除非契约明确且无符号可用（仍需报告）。

### 3.6 定时器/计数器/边沿

```scl
// 静态声明
TonRun : TON_TIME;
CtuPart : CTU_INT;
EdgeStart : R_TRIG;

// 调用
#TonRun(IN := #Start, PT := T#2S);
#RunDone := #TonRun.Q;

#CtuPart(CU := #Pulse, R := #Reset, PV := 10);
#PartCount := #CtuPart.CV;
#PartReached := #CtuPart.Q;

#EdgeStart(CLK := #Start);
#StartPulse := #EdgeStart.Q;
```

- 时间字面量用 `T#2S`/`T#200MS`/`T#1H30M`；不要写裸数字当时间。
- 计数器PV类型与实例类型匹配（`CTU_INT`对应Int等）。
- 定时器/计数器/边沿实例不得在`VAR_TEMP`；FC不得声明静态实例。

### 3.7 FC输出全分支

两种合规写法：

1. **临时变量法**（推荐，需契约提供临时变量）：
   - 每个输出对应一个临时变量；
   - 临时变量先赋安全默认值；
   - 所有分支只改临时变量；
   - 函数末尾一次性赋输出。
2. **互斥分支法**（契约无临时变量时）：
   - `IF/ELSIF/ELSE`或`CASE ... ELSE`的每个分支都给所有输出赋值；
   - 不在分支后再重复赋值；不提前`RETURN`。
   - 静态检查只能辅助，最终由工程师复核路径完整性。

安全默认值（`FALSE`/`0`）只用于输出初始化：若边界条件已定义、但输出初值未单列，可按“失效安全/去激励”处理并在日志标 `ASM-SAFE-DEFAULT`；若边界条件整体缺失，按2.5停止，不用默认值替代边界逻辑；若工艺要求其他安全值，停止，不猜。

### 3.8 DO单一写入者

- 每个DO只在一个拥有块中写入一次（推荐末尾一次性赋值）；其他块只读/传参。
- 禁止在OB、多个FB/FC、同一块多个不相干位置重复写同一DO。
- 若分支逻辑需要不同值，用临时变量/分支内局部结果，最后在拥有块一次性写DO；无临时变量时用互斥分支，且确保只有一个拥有块。
- 预检按“DO符号→赋值位置”跨文件统计；>1个拥有块即失败。

### 3.9 注释/编码

- 每个块头、关键段、边界/安全逻辑写中文注释；注释不替代代码。
- 注释用 `//`；不要用未闭合的 `(* ... *)`。
- 不在注释里写“已验证/已测试/已合规”。
- 块头注释块用中文（块名/类型/目标平台/用途/需求/契约/边界/生成时间），与 §3.1 三层规则一致：**注释层中文、`S7_BlockTitle` ASCII**；禁止块头只剩英文标签行，否则容易被误判为“注释不是中文”。
- 交付前抽查至少 1 个文件：按 UTF-8 解码应得到正常中文；按 GBK 解码应只出现预期乱码（用于说明 BOM 的必要性），文件中不得存在 `?` 或 `\ufffd` 替换字符。
- 文件末尾保留换行；不要混用CRLF/LF。

### 3.10 常见SCL错误（生成时避免）

| 错误 | 正确做法 |
|---|---|
| `VAR_STATIC` | FB静态区写 `VAR ... END_VAR` |
| 定时器/计数器放`VAR_TEMP` | 放FB静态`VAR`；FC用InOut/DB |
| `:=`/`=`混用 | 赋值`:=`；比较`=` |
| 缺`;` | 每条语句/`END_IF;`等补分号 |
| `ENDIF`/`ENDCASE` | 用`END_IF;`/`END_CASE;` |
| FC输出只在THEN赋值 | 全分支赋值/临时变量末尾赋值 |
| 同一DO多处赋值 | 唯一拥有块；一次写入 |
| `#`变量未声明 | 只用契约声明 |
| DB成员拼错 | 逐字用DB定义 |
| 块名/实例DB拼错 | 逐字用契约 |
| 时间裸数字 | `T#2S` |
| 中文变量名 | ASCII标识符，中文只放注释 |
| 文件编码错 | UTF-8 with BOM（EF BB BF）+CRLF；项目验证无 BOM 时转 GBK 或改英文；交付前回读校验 BOM |
| 中文注释乱码 | 表头写 BOM（utf-8-sig），不要只写 UTF-8 无 BOM；块头标签改中文 |

---

## 4. 生成流程

### 4.1 读取与建契约

1. 读取IO地址、DB定义、接口契约、需求；建立 `code_contract`。
2. 校验契约完整性；缺失→停止/部分生成。
3. 建调用图、DO拥有者、REQ覆盖表。
4. 标出未确认需求（`待定`/`待澄清`/`【模拟回答】`/`已关闭`）：不生成；报告。
5. 标出边界条件；缺失→契约缺口。

### 4.2 拆分生成Prompt

大型项目按FB/FC/工艺段拆分；每个块一个Prompt，只带本块依赖：

```text
【角色】西门子S7-1200 SCL工程师，TIA V21，CPU 1214C DC/DC/DC V4.6。
【本块】类型/块名/文件名。
【接口】逐字列出VAR_INPUT/OUTPUT/IN_OUT/VAR静态/VAR_TEMP。
【IO切片】只列本块使用的符号/地址/类型/NC语义/REQ。
【DB切片】只列本块使用的DB成员/类型。
【需求切片】只列本块实现的REQ/验收/边界。
【调用】调用者/被调用块/实例DB/顺序。
【约束】定时器/计数器静态；FC输出全分支；DO单写；只用契约符号；TIA格式。
【禁止】新增契约外的变量/全局 DB/接口/块；改输入；HMI/图纸/仿真；编造编译。
【输出】只输出本块.scl内容，不解释。
```

- 不把整个项目/全量DB/全量IO塞进一个Prompt。
- 依赖块先生成；OB最后。
- Prompt中缺失的契约项不得让模型“猜”，应停止并补契约。

### 4.3 生成代码

- 按调用图从叶子块→父块→OB生成；禁止循环调用；OB最后接线。
- 只生成契约内的块；不生成DB/HMI/图纸。
- 代码只实现需求/契约定义的功能；不新增模式/报警/定时器。
- 中文注释；块头写REQ/边界/“逻辑未验证”。
- 变量/接口/DB/IO逐字匹配；不新增声明。
- 写入 `./output/04-scl/src/`；覆盖同名块前记录旧文件/版本；不删除契约外文件。
### 4.4 生成后先静态预检

见第5节；预检不过不进入编译。预检问题写日志 `PC-xxx`，修复后再编译。

### 4.5 生成源码使用说明（推荐）

需要生成时，在 `./output/04-scl/src/使用说明/使用说明.md` 写入交付说明，内容取自本次契约与源文件（不是泛泛的通用说明），至少包含：

1. **交付清单**：块清单（块名/类型/文件/实例DB）、DB 清单、IO 符号表路径、各文件 SHA256；
2. **前置条件**：TIA 版本、CPU 型号与固件、项目已存在的工程对象（项目、CPU、tag 表、DB、OB1）；
3. **逐步操作**：由 `plc_tag_table.xml` 导入 PLC 变量表 → 建全局 DB（按 `db_definitions.xlsx` 逐字）→ 导入 `.scl`（外部源文件 → 从源生成块）→ 按契约生成/确认实例 DB → 编译 → 下载 → 在线监控与调试；
4. **编码说明**：UTF-8 with BOM + CRLF；导入后中文乱码时的两种处理（按 §3.1 例外条款转 GBK 或改英文）；
5. **故障排查表**：导入失败/符号未定义/DB 或实例 DB 不存在/编码错误/典型编译错误分类与处理方向；
6. **已知限制与免责**：编译是否执行、逻辑未验证、模拟契约/模拟裁决项、安全功能不得依赖本程序单独实现、需人工复核的边界条件；
7. **安全提示**：首次上电/调试前的硬线安全回路确认、急停与机械限位验证要求（只描述要求，不声称已验证）。

约束：使用说明只读引用本次产物与契约，不得新增功能、不得改写接口、不得写“已编译通过/已调试验证”等未发生的结论。

---

## 5. 静态预检（编译前）

### 5.1 检查项

| 检查 | 要求 |
|---|---|
| 文件/块 | 一文件一块；块类型/名称与契约一致；无DB/HMI |
| 变量段 | 顺序Input→Output→InOut→VAR静态→Temp；FC无静态 `VAR` |
| 关键字 | 不用`VAR_STATIC`；用`VAR`/`VAR_TEMP`/`END_VAR` |
| 定时器/计数器 | 只在FB静态`VAR`；不在`VAR_TEMP`；FC无静态实例 |
| 边沿实例 | `R_TRIG`/`F_TRIG`在静态区，不在TEMP |
| 接口 | 参数名/类型/方向/默认值与契约一致；不新增/删除 |
| 符号 | 每个`#`/`"..."`/DB成员在契约内；无未声明 |
| FC输出 | 每个输出有全分支赋值策略；无提前RETURN |
| DO单写 | 每个DO恰好一个拥有块；无跨块重复赋值 |
| 调用 | 块存在；实例 DB 允许在 FB 生成后按契约创建；输入`:=`/输出`=>`；无循环调用 |
| 结构 | IF/END_IF、CASE/END_CASE、FOR/END_FOR、WHILE/END_WHILE、REPEAT/END_REPEAT、VAR/END_VAR配对 |
| 格式/编码 | 分号、块结束、UTF-8 with BOM（EF BB BF）、CRLF；GBK 试解码无替换字符；中文注释可正常显示；块头标签为中文 |
| 追溯 | 每块有REQ；每个确认REQ有块落点；无未定义功能 |

### 5.2 预检脚本

- 可写 `./.scl_precheck/precheck.py`（临时，不作为交付物）；输出JSON `{pass, issues[]}`。
- 解析声明/赋值/调用；正则+轻量语法检查；不替代TIA编译器。
- 预检错误分级：`error`（阻止编译）、`warning`（记录，不阻止）。
- 预检不通过：只修代码/契约缺口；不进入编译；日志记录 `PC-xxx`。
- 预检修复最多2遍；仍不通过→停止，不进入编译，避免无限预检。

### 5.3 预检不能证明的事

- 不能证明逻辑正确、时序正确、边界完整；
- 不能替代TIA编译；
- 不能证明安全功能合规；
- 最终仍需工程师审阅/仿真/调试（本技能不做）。

---

## 6. 编译反馈闭环

### 6.1 编译通道

优先：

1. **TIA MCP 真实通道（首选）**，顺序固定：
   - `WritePlcSclSourceFile`：输出 UTF-8 带 BOM 的 `.scl`；
   - 同名外部源已存在时先 `DeletePlcExternalSource(softwarePath, externalSourceName)`，避免重名残留；
   - `ImportPlcExternalSource(softwarePath, groupPath, filePath)`；
   - 同名块已存在时先 `DeletePlcBlock(dryRun=false)`——`GenerateBlocksFromExternalSource` **不覆盖**旧块，会留下“能编译但逻辑是旧的”假象；
   - `GenerateBlocksFromExternalSource(softwarePath, externalSourceName)`；
   - `CompileAndDiagnosePlc(softwarePath)`：读 errors / warnings，最多 3 轮修复；
   - `ExportAsDocuments` 回读中文注释并比对（见 §3.1 硬门禁）；
   - `SaveProject`：不调用就不落盘。
2. `.s7dcl` 路线（批量导入/回读修复时用）：`.s7dcl` + `.s7res` 均为 UTF-8 带 BOM，`ImportFromDocuments(fileNameWithoutExtension, importPath, importOption="Override")`；`S7_MLC` 数量必须与 `.s7res` 条目一致，块标题保持 ASCII。
3. 用户提供的真实编译日志：按日志修复；不能声称“已重新编译”，除非再次编译。
4. 以上都没有：**编译未执行**；只做静态预检；日志写 `编译未执行` 和原因；不得编造错误码/通过。

编译前置：

- 工程前置：`Connect` → `OpenProject(项目.ap21)` 或 `AttachToOpenProject` → `GetProjectTree`；
- 从项目读取真实 `softwarePath`（PLC 软件名，不是设备名）、CPU 型号、tag 表、DB、OB1；
- 仅编译时：先用 `ImportPlcTagTable(softwarePath, folderPath, importPath)` 导入阶段3 的 `plc_tag_table.xml`；导入失败→`E07_*`，不进入编译。
- 本技能不创建 CPU/全局 DB/tag 表；进入 TIA 导入/编译时，全局 DB/OB1/tag 表必须已存在，缺失→`E07_PROJECT_OBJECT_MISSING`（`blocked`）；仅源码/静态预检模式可缺省，日志写 `编译未执行：工程对象缺失`；
- 实例 DB：FB 生成后按契约用 `CreateInstanceDB` 创建，名称/编号逐字取契约；已存在则复用并校验，不重复创建；不得新建契约外实例。
- 缺工程对象→`【工程前置缺口：...】`，`blocked`，不生成假 DB/tag。

### 6.2 编译消息解析

- 保留原始错误码/消息/块/路径/行号；不要改写/编造。
- 映射到源文件/行；没有行号时按块+文本定位。
- 分类：`E-IMPORT`/`E-SYNTAX`/`E-SYMBOL`/`E-TYPE`/`E-INTERFACE`/`E-DB`/`E-INSTANCE`/`E-STATIC`/`E-OUTPUT`/`E-DUP-DO`/`E-ENCODING`/`E-COMPILER`/`W-*`。
- 未知格式：保留原文，标`E-UNKNOWN`，请工程师提供格式说明；不猜。

### 6.2.1 LLM 导入-编译-修复闭环（可执行）

输入：`src/<Block>.scl`（UTF-8 BOM）、`softwarePath`、接口契约。
上限：3 轮；每轮只改“报错相关语句”，不改业务逻辑。

每轮固定动作：

1. **覆盖准备**：`GetBlocksWithHierarchy` 查同名块；存在则 `DeletePlcBlock(softwarePath, blockPath, dryRun=false)`。
   原因：`GenerateBlocksFromExternalSource` **不覆盖**旧块，不删就会出现“编译 0 错误，逻辑还是旧的”。
   > `DeletePlcBlock` 默认挂在人工审批卡上：审批卡即每轮的人机检查点；若需全自动闭环，由用户显式移除该保护，不得默认关闭。
2. **导入（仅编译时）**：`WritePlcSclSourceFile` → `ImportPlcExternalSource` → `GenerateBlocksFromExternalSource`；如契约需要实例 DB，在 FB 生成后用 `CreateInstanceDB` 创建（名称/编号取契约；已存在则复用并校验）。
3. **编译**：`CompileAndDiagnosePlc(softwarePath)`，逐条取 errors 的 Path / Description / 行号。
4. **判定**：
   - errors=0 → 进入第 5 步回读校验，通过则结束；
   - errors>0 且轮次 < 3 → 进入第 6 步 LLM 修复；
   - 轮次=3、或本轮无代码变更仍有错误、或同一错误连续两轮未消失 → 停止，转人工。
5. **回读**：`ExportAsDocuments` 校验中文注释（见 §3.1 硬门禁），再 `SaveProject`。
6. **LLM 修复**：把“块源码 + 全部 errors + 契约接口”交给模型，按 §6.3 允许项修改；只输出完整块源码（不是 diff），保留中文注释与 BOM；改完回到第 2 步。

每轮必须写 `compilation_fix_shturl`：

```text
Round N | errors=n warnings=m | 错误码/块/行 | 改了什么 | 结果（通过/仍有错误/无进展）
```

禁止事项：

- 不得用“重试一次”代替修复；每轮必须有可回指的修改；
- 不得并行改多个块后只编译一次——每块独立成轮，错误归属才可追溯；
- 不得把“同一错误反复改写法”当进展；连续两轮同一错误未消失即 `E08_NO_PROGRESS`。

### 6.3 允许的修复

| 类别 | 允许 |
|---|---|
| 语法/格式 | 补分号、配对、块头/结束、缩进、编码 |
| 未声明/拼写 | 改成契约内精确符号；契约没有→停止，不自增 |
| 类型不匹配 | 按契约类型加显式转换；不改接口；无法转换→停止 |
| 定时器/计数器TEMP | 移到FB静态；契约无静态实例→停止，要求补契约 |
| FC输出未赋值 | 临时变量末尾赋值/全分支赋值；不新增变量（除非契约有） |
| DO重复赋值 | 合并到唯一拥有块；改变逻辑→报告，不静默 |
| 全局 DB/块缺失 | 不改全局 DB、不建块；报工程前置/契约缺口 |
| 实例 DB 缺失 | 可在 FB 生成后按契约创建（CreateInstanceDB），已存在则复用并校验；契约无名称/编号→停止 |
| 导入/编码 | 修正编码/块头/文件格式；不改逻辑 |
| 编译器内部错误 | 记录；最多重试一次；不伪造通过 |

### 6.4 不允许的修复

- 修改IO表/DB定义/接口契约/需求；
- 新增契约外的变量/全局 DB/接口/块/实例 DB；
- 为了让编译通过而删功能/改需求/改安全逻辑；
- 把定时器/计数器改到TEMP；
- 把多个DO写操作合并成“看似通过”但逻辑不明的代码；
- 编造编译消息/错误码/通过状态；
- 用仿真代替编译。

### 6.5 轮次与收敛

```text
Round 0：基线静态预检 + 首次编译
Round 1：修复 → 重编译
Round 2：修复 → 重编译
Round 3：修复 → 重编译
```

- 最多3轮代码修复；Round 3后仍失败→转人工。
- 每轮记录：源文件哈希、错误数/警告数、修复项、残余。
- 同一错误修复后重复出现：不得重复同一改法；分析原因或停止。
- 一轮无代码变更且仍有错误：停止（无进展）。
- 契约缺口/工程前置缺口：不消耗修复轮次，立即停止并报告。
- 编译成功：停止；记录警告/残余风险；不继续“优化逻辑”。

### 6.5.1 每轮 LLM 修复提示词（固定模板）

```text
【角色】西门子 SCL 修复工程师，TIA Portal V21。
【输入】块名、契约接口、当前完整源码、编译诊断（逐条：块/行/错误码/原文）。
【任务】只修复下列错误；每条错误必须对应一处修改，并在回复开头列出“错误→改法”对照表。
【允许】补分号/配对/块头、改契约内符号拼写、加显式类型转换、定时器/计数器移入静态区、FC 输出全分支赋值。
【禁止】新增契约外的变量/全局 DB/接口/块/实例 DB；改 IO 表/契约/需求；删功能；改安全逻辑；动中文注释；伪造编译结果。
【输出】只输出完整块源码（不是 diff），不要解释性长文；无法安全修复时只输出“转人工：<原因>”。
```

使用约束：

- 每轮只喂“当前块”的源码与诊断，不喂整个项目，避免模型误改其他块；
- 诊断原文必须逐字附上，不得由编排层概括成“类型错误”这类模糊描述；
- 模型输出必须重新过 §3.1 编码校验（BOM + 回读中文），再进入下一轮导入。

### 6.6 人工接管

触发：

- 3轮后仍有错误；
- 需要改契约/DB/IO/接口/实例DB；
- 编译器内部错误；
- 无法定位/无法安全修复；
- 需求/边界冲突。

接管内容：未解决错误、文件/行、疑似根因、已尝试修复、需要的契约/工程变更、建议人工动作。不得声称完成。

### 6.7 成功标准

- TIA编译器返回成功（0 errors）；
- 所有源文件导入成功；
- 静态预检无error；
- 日志记录编译器版本/时间/源哈希；
- 最终状态：`编译通过（仅语法/接口；逻辑未验证）`。

编译通过不等于逻辑正确、安全合规、现场可用。

---

## 7. compilation_fix_shturl 日志

### 7.1 路径/格式

- 固定路径 `./output/04-scl/compilation_fix_shturl`；**无扩展名**。
- UTF-8文本；Markdown式表格/标题即可；不要改名成`.md`（除非用户明确要求）。
- 只记录真实编译/预检结果；没有编译就写“编译未执行”。

### 7.2 内容

```markdown
# SCL编译报错与修复日志

## 0. 概要
- 项目/CPU/TIA版本：
- 源目录/块清单：
- 源码使用说明路径：./output/04-scl/src/使用说明/使用说明.md
- 接口/DB/IO/需求版本：
- 编译工具/版本：
- 初始状态/最终状态：
- 逻辑验证：未执行（仅编译/静态预检）

## 1. 契约与源文件
| 块 | 类型 | 文件 | SHA256 | 接口版本 |
...

## 2. 轮次
| Round | 源哈希 | 错误 | 警告 | 修复 | 结果 |
|---|---|---|---|---|---|
| 0 | ... | ... | ... | ... | ... |
| 1 | ... | ... | ... | ... | ... |

## 3. 错误与修复
### ERR-001
- 轮次：
- 编译器错误码：
- 原始消息：
- 文件/行/块：
- 分类：
- 根因：
- 修复：
- 结果：已修复/残余/需契约变更

## 4. 残余错误与人工接管
...

## 5. 警告/风险
...

## 6. 结论
- 编译状态：通过/3轮未通过/未执行/预检未通过/契约缺口
- 逻辑验证：未执行
- 输入修改：无
```

### 7.3 规则

- 编译器原始消息保留；可附中文解释，但不能替换原文。
- 每个错误有唯一`ERR-xxx`；每轮编号连续。
- 修复必须对应到文件/行/改动摘要；不贴整段代码。
- 源哈希用SHA256；修复后更新。
- 3轮失败写“转人工”，列残余；不写“基本通过”。
- 编译未执行写原因（无工具/无日志/工程前置缺失）。
- 不写“已验证逻辑/已调试/可现场运行”。

---

## 8. 交付前自检清单

> **附加强制项（2026-11-16）**：本清单之外还必须逐条满足附录 Z 的 S-01~S-06，任一条不满足不得声明本阶段完成。

- [ ] `./output/04-scl/src/` 存在；只有OB/FB/FC `.scl`；一块一文件（唯一例外：`使用说明/` 子目录仅含使用说明 `.md`）。
- [ ] 如生成使用说明：`./output/04-scl/src/使用说明/使用说明.md` 存在且非空；含交付清单/前置条件/逐步操作/编码说明/故障排查/已知限制，且无“已编译通过、已验证”等未发生结论；未生成不阻断（推荐交付物）。
- [ ] 块名/文件名/接口与契约逐字一致；无新增/删除/改名。
- [ ] FB静态区用`VAR`，不是`VAR_STATIC`；FC无静态`VAR`。
- [ ] 所有定时器/计数器/边沿实例在FB静态`VAR`；无TEMP实例。
- [ ] 每个FC输出全分支赋值；无提前`RETURN`导致未赋值。
- [ ] 每个DO只有一个拥有块；无跨块重复赋值。
- [ ] 所有`#`/`"..."`/DB成员/块/实例DB在契约内；无自增。
- [ ] 调用参数`:=`/`=>`正确；无循环调用/未定义块。
- [ ] 语法结构配对；分号；块结束；编码为 UTF-8 with BOM（EF BB BF）+ CRLF，已回读字节校验（项目要求无 BOM 时，已转 GBK 或改英文并写入日志）。
- [ ] 块头标签为中文；抽查文件无 `?`/`\ufffd` 替换字符。
- [ ] 中文注释存在；标识符ASCII；无HMI/图纸/DB源输出。
- [ ] 已完成真实编译或明确“编译未执行”；无编造错误/通过。
- [ ] 最多3轮；未通过已转人工。
- [ ] `compilation_fix_shturl` 存在且内容真实；路径无扩展名。
- [ ] 最终状态为“编译通过（逻辑未验证）”/“转人工”/“未执行”，不冒充逻辑正确。

---

## 9. 对话输出契约

### 9.1 完成（编译通过）

- 源文件目录/块清单；
- 编译工具/版本、轮次、错误修复数/警告数；
- 日志路径；
- 明确“仅语法/接口通过，逻辑未验证；未仿真/未调试”；
- 不声称“可现场运行/安全合规”。

### 9.2 未通过/转人工

- 最终状态`3轮未通过，转人工`；
- 残余错误ID/文件/行/根因；
- 已尝试修复；
- 需要补的契约/工程对象；
- 不继续第4轮。

### 9.3 阻塞

```text
【契约缺口：...】
【工程前置缺口：...】
【缺少编译通道：...】
【编译未执行：...】
【3轮未通过：...】
```

说明已生成/未生成哪些块；不编造。

### 9.4 禁止

- 不生成HMI/图纸/DB/仿真；
- 不修改输入契约/IO/DB；
- 不新增变量/接口/块；
- 不编造编译结果/错误码；
- 不把编译通过说成逻辑正确。

---

## 附录 A：FB/FC/OB最小模板

### A.1 OB

```scl
ORGANIZATION_BLOCK "OB_Main"
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
BEGIN
	"FB_Name_DB"(Start := "DI_Start", Run => "DO_Run");
END_ORGANIZATION_BLOCK
```

### A.2 FB

```scl
FUNCTION_BLOCK "FB_Name"
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
   VAR_INPUT
      Start : Bool;
   END_VAR
   VAR_OUTPUT
      Run : Bool;
   END_VAR
   VAR
      Ton1 : TON_TIME;
      Ctu1 : CTU_INT;
      Edge1 : R_TRIG;
      State : Int;
   END_VAR
   VAR_TEMP
      tmp : Bool;
   END_VAR
BEGIN
	#Edge1(CLK := #Start);
	#Ton1(IN := #Start, PT := T#2S);
	#tmp := #Ton1.Q;
	#Run := #tmp;
END_FUNCTION_BLOCK
```

### A.3 FC

```scl
FUNCTION "FC_Name" : Void
{ S7_Optimized_Access := 'TRUE' }
VERSION : 0.1
   VAR_INPUT
      Fault : Bool;
   END_VAR
   VAR_OUTPUT
      Lamp : Bool;
   END_VAR
   VAR_TEMP
      tmpLamp : Bool;
   END_VAR
BEGIN
	#tmpLamp := FALSE;
	IF #Fault THEN
	    #tmpLamp := TRUE;
	ELSE
	    #tmpLamp := FALSE;
	END_IF;
	#Lamp := #tmpLamp;
END_FUNCTION
```

- 模板仅示语法；接口/变量必须按契约增删，不得照抄新增。

## 附录 B：编译错误分类/修复速查

| 分类 | 典型消息 | 首选修复 |
|---|---|---|
| E-IMPORT | 无法导入/未知格式 | 修块头/编码/文件格式；不改逻辑 |
| E-SYNTAX | 缺少`;`/`END_IF`/`THEN` | 补语法；配对 |
| E-SYMBOL | 未声明/未知符号 | 改成契约精确名；契约没有→停止 |
| E-TYPE | 类型不匹配 | 契约允许的显式转换；否则停止 |
| E-INTERFACE | 参数/接口不匹配 | 按契约改调用/接口；不新增参数 |
| E-DB | DB/成员不存在 | 不改DB；报契约/工程缺口 |
| E-INSTANCE | 实例DB不存在 | 按契约名称/编号创建；契约缺失→报缺口 |
| E-STATIC | TEMP实例/静态错误 | 移到FB静态`VAR`；无静态→停止 |
| E-OUTPUT | 输出未赋值 | 全分支/临时变量末尾赋值 |
| E-DUP-DO | DO重复写入 | 合并到唯一拥有块；逻辑变更需报告 |
| E-ENCODING | 编码错误/中文注释乱码 | 补 UTF-8 BOM（EF BB BF）；或按项目要求转 GBK/改英文；不改逻辑 |
| E-COMPILER | 编译器内部错误 | 记录；最多重试一次；转人工 |

## 附录 C：FC输出全分支检查表

- [ ] 每个输出在函数末尾有赋值，或被所有互斥分支覆盖。
- [ ] 没有`RETURN`跳过后面的输出赋值。
- [ ] 没有只在`THEN`赋值、`ELSE`缺失。
- [ ] 没有默认赋值后再被未覆盖分支跳过。
- [ ] 临时变量先赋初值；不读未初始化TEMP。
- [ ] 安全默认值有契约/日志依据。

## 附录 D：DO单一写入者检查表

- [ ] 每个DO在`do_owners`中恰好一个拥有块。
- [ ] 其他块只读/通过参数传命令，不写该DO。
- [ ] 拥有块内推荐末尾一次赋值；分支只改临时/静态中间量。
- [ ] 无跨文件/跨OB重复赋值。
- [ ] 逻辑合并导致行为变化时，已报告，不静默。

## 附录 E：TIA V21导入检查

- [ ] 一块一文件；块类型/名称正确。
- [ ] `{ S7_Optimized_Access := 'TRUE' }`、`VERSION : 0.1`。
- [ ] `FUNCTION_BLOCK`/`FUNCTION`/`ORGANIZATION_BLOCK` 与 `END_*` 配对。
- [ ] 变量段顺序正确；FB静态用`VAR`；FC无静态。
- [ ] `END_*` 后无分号；语句有分号。
- [ ] 时间字面量`T#...`；调用`:=`/`=>`。
- [ ] UTF-8 with BOM（EF BB BF）+CRLF；中文只在注释；块头标签为中文。
- [ ] 无`VAR_STATIC`；无`PROGRAM`；无DB源输出。
- [ ] TIA项目已有 tag 表/全局 DB/OB1/硬件组态；实例 DB 按契约创建。
- [ ] 如生成使用说明：与本次块清单/DB/编码一致；未生成不阻断（推荐交付物）。

## 附录 F：编译日志最小模板

```text
# SCL编译报错与修复日志
## 0. 概要
项目/CPU/TIA版本：
源目录：
编译工具/版本：
初始/最终状态：
## 1. 源文件
块/类型/文件/SHA256/接口版本
## 2. 轮次
Round/源哈希/错误/警告/修复/结果
## 3. 错误
ERR-xxx：错误码/原始消息/文件行/分类/根因/修复/结果
## 4. 残余/人工接管
## 5. 警告/风险
## 6. 结论
编译状态：
逻辑验证：未执行
输入修改：无
```

## 附录 G：允许/禁止修复边界

| 情况 | 允许 | 禁止 |
|---|---|---|
| 语法错误 | 修语法 | 删功能绕过 |
| 符号拼错 | 改契约内精确名 | 新增同名变量 |
| 类型不匹配 | 契约内显式转换 | 改接口类型 |
| 定时器在TEMP | 移FB静态 | 放FC TEMP/新建未契约实例 |
| FC输出未赋值 | 全分支/临时变量 | 新增未契约临时变量 |
| DO重复 | 合并唯一拥有块 | 静默改逻辑/保留双写 |
| DB/实例缺失 | 报缺口 | 自建DB/实例 |
| 编译不过 | 3轮修复/转人工 | 伪造通过 |

## 附录 H：与上游文件的只读边界

- `io_address.xlsx`：只读；不改地址/符号/类型。
- DB定义：只读；不改成员/类型/默认值。
- 接口契约：只读；不改参数/静态/实例。
- `requirements_spec.xlsx`：只读；不改需求/状态。
- 需要变更→写`contract_change_request`到日志，等工程师确认；不直接改。

---

## 附录 Z：实机回归失败模式与强制检查

> 来源：2026-11-16 首次在 PLCSIM Advanced 上真实执行 81 条用例（不是设计推演；项目与设备信息已脱敏），
> 结果 56 通过 / 25 不符。以下每条都由**真实失败**反推，不是假设。
> 编号规则在各技能内唯一，交付前逐条打勾；任一条不满足不得声明阶段完成。

### Z.1 业务拒绝不得进入故障锁存（S-01 · 强制）

写故障块时必须满足：

- 只有**设备故障类**条件可以置 `FaultLatch` / `FaultActive`
- 业务拒绝类（满位、无车、未支付、未授权）只能拒绝本次操作，**不得**置故障位
- 若需求要求把业务条件当"第 N 类状态"上报，则**只上报代码，不置 FaultActive**（参考实现：`code` 计算排除该位，`FaultActive := (code<>0) AND (code<>N)`）

### Z.2 常闭触点与上电屏蔽（S-02 · 强制）

- 所有来自现场的 NC 触点必须**显式取反**（`NOT "STOP_NC"`），注释写明"TRUE=正常"
- 上电首扫描必须有输入有效性处理：**不得**因 I 区为 0 直接判为"动作"。做法：加 `FirstScan` 屏蔽窗口或延时确认（例如 500 ms 内不置锁存）

> 真实事故：首扫描 I=0 → 急停与 13 路过载全部判为动作 → 上电即锁存，复位还要工程师权限，现场表现为"一上电就坏了"。

### Z.3 故障位来源唯一性（S-03 · 强制）

每个 `INT_FaultXxx` 只能有**一个**写入者，且必须与判定条件一一对应。交付前自查：列出全部故障位 → 列出写入它的块 → 必须都是 1:1。
> 真实事故：`FB_StoreFlow` 读到的 `FaultActive` 为 TRUE，而 `INT_FaultActive` 位读出 0、故障码为 0、全部故障源为 False —— 该不一致让 15 条流程类用例永久不受理请求。

### Z.4 HMI 输入与显示必须分名（S-04 · 强制）

- 输入类：`*_IN`（按钮、模式选择、权限、参数）
- 显示类：`*_DISP`（动画位、提示、故障码、计数）
- 同一变量不得既被 FC 当输入读、又被当作显示写

### Z.5 状态量禁止 BOOL（S-05 · 强制）

步序、编码、故障码、计数一律用 `INT`/`DINT`；**不得**用 BOOL 承载"当前第几步"。
> 真实事故：`INT_SeqStep` 被定义为 M 位（BOOL），只能表达"忙/闲"，与"步序≥1"的用例判定口径冲突。

### Z.6 编译通过 ≠ 可交付：冒烟移交阶段5（S-06 · 强制）

编译 0 error 只证明语法与接口。冒烟执行**不在本阶段做**（本技能红线 7：不仿真、不调试；且此时阶段5 用例尚未生成）。

- 本阶段结束时 `compilation_fix_shturl` 必须写明"冒烟未执行，移交阶段5"，并由编排层记 `+logic_unverified`；
- 阶段5 按 `sim-trace-05` §4.1.2 先跑 3 条冒烟（正常/急停/复位），结果回填 `results.xlsx`；
- 本阶段不得以"编译通过"宣称程序可交付，也不得自行跑仿真或下载到真机来代替。

### Z.7 静态门禁脚本（S-01~S-05 可机器判定）

本技能交付前**必须**执行阶段4 静态门禁，不通过不得声明阶段完成：

```bash
python <skills>/auto-flow-master-00/assets/checkers/check_stage4.py --project <项目根>
```

退出码 `1` 即为门禁 FAIL。它能机检的条目：单一写入者(S-03)、NC 未取反(S-02)、
状态量用 Bool(S-05)、实例未静态化、HMI 输入/显示混用(S-04)、有锁存无上电屏蔽(S-02)。
规则与自定义 profile 见同目录 `README.md`；**脚本不写死任何项目内容**，换项目只换 `--profile`。
